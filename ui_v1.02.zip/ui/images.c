#include "images.h"

const ext_img_desc_t images[14] = {
    { "wallpaper", &img_wallpaper },
    { "user", &img_user },
    { "WY", &img_wy },
    { "mylike_un", &img_mylike_un },
    { "mylike_pr", &img_mylike_pr },
    { "ONE_LAST_KISS", &img_one_last_kiss },
    { "miku", &img_miku },
    { "mylike_img", &img_mylike_img },
    { "lastest_un", &img_lastest_un },
    { "last_pr", &img_last_pr },
    { "collect_un", &img_collect_un },
    { "collect_pr", &img_collect_pr },
    { "FM_un", &img_fm_un },
    { "FM_pr", &img_fm_pr },
};
