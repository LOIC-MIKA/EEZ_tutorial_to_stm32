#include "ui.h"
#ifndef __EVENT_H
#define __EVENT_H
#define REQUIRED_INPUT_USER "miku"
#define REQUIRED_INPUT_PSWD "39"
void textarea_event_handler(lv_event_t *e);
void wallpaper_event_handler(lv_event_t *e);
void U_check_event_handler(lv_event_t *e);
void P_check_event_handler(lv_event_t *e);
void signin_event_handler(lv_event_t *e);
void mylikesbtn_event_handler(lv_event_t *e);
#endif
