//#include <string.h>
//
//#include "screens.h"
//#include "images.h"
//#include "fonts.h"
//#include "actions.h"
//#include "vars.h"
//#include "styles.h"
//#include "ui.h"
//#include "EVENT.h"
//#include <string.h>
//#ifndef __CALL_FUNCTION_H
//#define __CALL_FUNCTION_H
//void event_paper();
//void event_user();
//void event_pswd();
//#endif
