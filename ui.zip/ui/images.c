#include "images.h"

const ext_img_desc_t images[7] = {
    { "wallpaper", &img_wallpaper },
    { "user", &img_user },
    { "WY", &img_wy },
    { "mylike_un", &img_mylike_un },
    { "mylike_pr", &img_mylike_pr },
    { "ONE_LAST_KISS", &img_one_last_kiss },
    { "miku", &img_miku },
};
